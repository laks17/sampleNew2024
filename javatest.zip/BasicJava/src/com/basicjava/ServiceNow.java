package com.basicjava;

public class ServiceNow {
	
	public static void main(String args[]) {
		
		System.out.print("hi wowrd");
	}
}