package com.basicjava;

public class CalculateRalated {
	public float calEmi(int t,float r, int a) {
		float emi=a*r/t*60;
		return emi;
	}
	public int sum(int [] v) {
	
		return 0;
		
	}
	
	public static void main(String args[]) {
		int tenur=5;
		float roi=12f;
		int amount=490000;
		CalculateRalated ce=new CalculateRalated();
		float calEmi=ce.calEmi(tenur, roi, amount);
		float finalAmount=calEmi+500;
		System.out.println(finalAmount);
		int [] values= {10,20,30,40};
		ce.sum(values);
		
	}
}