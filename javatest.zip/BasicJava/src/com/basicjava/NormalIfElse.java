package com.basicjava;

public class NormalIfElse {

	public static void main(String[]args) {
		
		System.out.println("Satement1");
		System.out.println("Satement2");
		if(10>9) {
		System.out.println("Satement3");
		System.out.println("Satement4");
		}
		else{
			System.out.println("Satement5");
		}
		System.out.println("Satement6");
	}
	
}
