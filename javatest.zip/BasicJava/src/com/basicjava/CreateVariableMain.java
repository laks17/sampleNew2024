package com.basicjava;

public class CreateVariableMain {
	
private	String name;   //instance member variable //heap memory
	public int account;  //instance variable    //heap memory
	protected int age; //instance variable //heap memory
	int aadharNumber; //instance variable //heap memory
	static String bankName;  //static variable // method area
	
	public static void transection() {  //static we used so its store methed area and access by class name
        System.out.println("access by the class name");
	}
public void editProfile() {   //instance member
	int a=10;  //local variable     stack memory
	System.out.println(a);
	System.out.println(name);
	
}

public static void main(String args[]) {  //static member funtion
	
	CreateVariableMain c1=new CreateVariableMain();   //cv reffrence variable // stack memory///cv address 
	c1.name="Lax";
	c1.account=123;
	c1.age=30;
	c1.aadharNumber=1234;
	CreateVariableMain c5=c1;
	System.out.println(c1.name);
	CreateVariableMain c2=new CreateVariableMain(); 
	c2.name="moorthy";
	c2.account=7854;
	CreateVariableMain.bankName="icici"; ///static variable we can access by the class name
	System.out.println(CreateVariableMain.bankName);
	CreateVariableMain.transection();
}
}
