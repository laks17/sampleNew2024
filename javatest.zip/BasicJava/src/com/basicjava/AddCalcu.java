package com.basicjava;

public class AddCalcu {
	
     int add() {
    	 
    	 int a=10+20;
       return a;	 
    
     }

     public static void main(String args[]) {
    	 
    	 AddCalcu ac=new AddCalcu();
    	 
    	 int result=ac.add();
    	 System.out.println(result);
    	 
     }
}
