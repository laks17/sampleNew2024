package com.basicjava;

public class Demo {

	static int a=51;
	static int b=49;
	static int c=a+b;
	
	public void serviceNow(){
		int a=1;
		int b=9;
		int d=a+b;
	System.out.println(d);
		
	}
	public void divide() {   //function diffination
		System.out.println("divide");
	}
	public static void main(String args[]) {
		
		Demo dd=new Demo();
		dd.serviceNow();
		System.out.println(c); //function call
		dd.divide();
		
		
	}
	
	
}
