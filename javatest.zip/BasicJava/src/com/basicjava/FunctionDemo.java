package com.basicjava;

public class FunctionDemo {

	public void add() {
		System.out.println("add");

	}
     public static void main(String args[]) {
    	 System.out.println("main");
    	 FunctionDemo fd=new FunctionDemo();
    	 fd.add();
     }
}
